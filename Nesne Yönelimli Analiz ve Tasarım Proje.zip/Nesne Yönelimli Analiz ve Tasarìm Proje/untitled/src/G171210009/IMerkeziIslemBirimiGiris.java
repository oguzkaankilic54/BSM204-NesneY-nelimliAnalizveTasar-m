package G171210009;

public interface IMerkeziIslemBirimiGiris {
    boolean girisYap(String userName, String password) throws InterruptedException;
}
