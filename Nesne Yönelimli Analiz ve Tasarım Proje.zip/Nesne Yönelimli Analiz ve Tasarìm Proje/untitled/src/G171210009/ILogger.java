package G171210009;

public interface ILogger {
    void log(String mesaj);
}
