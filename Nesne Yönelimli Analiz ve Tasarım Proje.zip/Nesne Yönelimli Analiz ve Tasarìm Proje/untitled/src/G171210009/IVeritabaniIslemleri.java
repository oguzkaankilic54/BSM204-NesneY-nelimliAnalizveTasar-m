package G171210009;

public interface IVeritabaniIslemleri {
    boolean girisYap(String k_adi, String pass);
}
